package ca.mobile.assignment1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText hours;
    private EditText rate;

    private TextView payText;
    private TextView taxText;
    private TextView totalPay;
    private TextView overText;

    private double dHour;
    private double dRate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       hours = (EditText) findViewById(R.id.hour_edit);
       rate = (EditText) findViewById(R.id.rate_edit);

       payText = findViewById(R.id.pay_txt);
       taxText = findViewById(R.id.tax_txt);
       totalPay = findViewById(R.id.total_txt);
       overText = findViewById(R.id.over_txt);

        Button cal = findViewById(R.id.cal_btn);
        cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculation();
            }
        });
    }


    private void calculation()
    {
        String h = hours.getText().toString();
        String r = rate.getText().toString();
        if(h.length()>0 && r.length()>0)
        {
            try {
                dHour = Double.parseDouble(h);
                dRate = Double.parseDouble(r);

                double pay;
                double overPay = 0.0;
                double total;

                if (dHour <= 40) {
                    total = dHour * dRate;
                } else {
                    overPay = (dHour - 40) * dRate * 1.5;
                    total = overPay + 40 * dRate;
                }

                pay = total - overPay;

                double tax = total * 0.18;

                payText.setText("Pay: " + pay);
                overText.setText("Overpay: " + overPay);
                totalPay.setText("Total: " + total);
                taxText.setText("Tax: " + tax);
            }
            catch (Exception e)
            {

            }
        }
        else
        {
            Toast.makeText(this, "Enter Values!", Toast.LENGTH_SHORT).show();
            payText.setText("Pay: " );
            overText.setText("Overpay: " );
            totalPay.setText("Total: " );
            taxText.setText("Tax: " );
        }
    }


    private void startSecond()
    {
        Intent inte =new Intent(getApplicationContext(),AboutActivity.class);
        startActivity(inte);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inf = getMenuInflater();
        inf.inflate(R.menu.main_menu,menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

       switch (item.getItemId())
       {
           case R.id.about: startSecond(); break;
           default: return super.onOptionsItemSelected(item);
       }
       return true;

    }
}